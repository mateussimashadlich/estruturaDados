class Ordenacao{

    public void mergeSort(int[] v, int p, int r){
        //int p -> index do primeiro elemento a ser ordenado(inicia com 0)
        //int r -> index do último elemento a ser ordenado(inicia com n-1)
        if(p < r){
            int q = Math.ceil((p+r)/2);
            mergeSort(v, p, q);
            mergeSort(v, q + 1, r);
            merge(v, p, q, r);
        }
    }

    public void merge(int[] v, int p, int q, int r){
        int n1 = q - p + 1;
        int n2 = r - q;
        int[] L = new int[n1];
        int[] R = new int[n2];
        for(int i = 0; i < n1 - 1; i++){
            L[i] = v[p + i];
        }
        for(int j = 0; i < n2 - 1; j++){
            R[j] = v[q + j + 1];
        }
        //L[n1] = "infinito";
        //R[n2] = "infinito";
        i = 0;
        j = 0;
        for(int k = p; k <= r; k++){
            if(L[i] <= R[j]){
                v[k] = L[i];
                i++;            
            }
            else{
                v[k] = R[j];
                j++;
            }
        }
    }
    public void quickSort(int[] v, int a, int b){
        if( a < b){
            int indicePivo = particiona(v, a, b);
            quickSort(v, a, indicePivo-1);
            quickSort(v, indicePivo+1, b);
        }
    }

    private int particiona(int[] v, int a, int b){
        int x = v[a];
        while(a < b){
            while(v[a] < x){
                a++;
            }
            while(v[b] > x){
                b--;
            }
            troca(v, a, b);
        }
        return a;
    }

    private void troca(int[] v, int a, int b){
        int temp = v[a];
        v[a] = v[b];
        v[b] = temp;
    }
    /*public void quickSort(int[] v, int index_pivo, int limite){
        int temp;        
        int pivo = v[index_pivo];        
        for(int i = ; i < limite; i++){
            if(v[i] < pivo){
                temp = v[i];
                v[i] = pivo;
                index_pivo = i;
                remanejarLista(v, temp, index_pivo);        
            }
        }
        quickSort(v, index_pivo + 1, v.length - 1);
        quickSort(v, 0, index_pivo);        
    }

    public void sort(int[] v, int inicio, int fim){
        int temp;
        int pivo = v[inicio];
        for(int i = inicio; inicio < fim; i++){
            if(v[i] < pivo){
                temp = v[i];
                v[i] = pivo;
                remanejarLista(v, temp, index_pivo);
            }
        }
        sort(v, 0 , v[inicio]);
        sort(v, v[inicio] + 1, v.length-1);
    }
    public void remanejarLista(int[] v, int valor, int i){
        int temp;
        for(int j = v[i-1]; j >= 0; j--){
            temp = v[j]; // valor da posição atual.
            v[j] = valor; // valor da pos. atual é substituído pelo valor da pos. sucessora.
            valor = temp; // salva valor da pos. atual na var. valor da pos. sucessora.
        }
    }
    */
}