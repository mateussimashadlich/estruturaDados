import java.util.Random;

class Teste{
    public static void main(String[] args){

        int v1 = new int[(int)Math.pow(10, 1)];
        int v2 = new int[(int)Math.pow(10, 2)];
        int v3 = new int[(int)Math.pow(10, 3)];
        int v4 = new int[(int)10^4];
        System.out.println(10^3);
        System.out.println(Math.pow(10, 3));
        int[] bla = {3, 4, 1, 0, 33, 32, 10, 11, 12};
        /*Ordenacao ordenacao = new Ordenacao();
        ordenacao.quickSort(bla, 0, bla.length-1);
        for(int i: bla){
            System.out.println(i);
        }        
        */
    }
}